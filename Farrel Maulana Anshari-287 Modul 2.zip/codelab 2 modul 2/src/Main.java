public class Main {
    public static void main(String[] args) {

        RekeningBank rekening1 = new RekeningBank("2552", "Farrel", 1000000);
        RekeningBank rekening2 = new RekeningBank("6776", "Anshari", 500000);


        System.out.println("Informasi rekening 1:");
        rekening1.tampilkanInfo();

        System.out.println("Informasi rekening 2:");
        rekening2.tampilkanInfo();


        rekening1.setorUang(500000);


        rekening2.tarikUang(50000);


        rekening1.tarikUang(100000);
    }
}
