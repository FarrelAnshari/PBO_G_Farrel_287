// Subclass Musuh, yang merupakan turunan dari class KarakterGame
class Musuh extends KarakterGame {
    // Constructor untuk class Musuh
    // Digunakan untuk mengatur nama dan kesehatan awal dari objek Musuh
    public Musuh(String nama, int kesehatan) {
        super(nama, kesehatan); // Memanggil constructor superclass (KarakterGame)
    }
    // Method ini mendefinisikan bagaimana Musuh menyerang target
    @Override
    public void serang(KarakterGame target) {
        // Menampilkan pesan bahwa Musuh menyerang target dengan serangan khusus
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan Snake Bite!");

        // Mengurangi kesehatan target sebesar 15
        target.setKesehatan(target.getKesehatan() - 15);

        // Menampilkan kesehatan terbaru target setelah diserang
        System.out.println(target.getNama() + " sekarang memiliki kesehatan " + target.getKesehatan());
    }
}