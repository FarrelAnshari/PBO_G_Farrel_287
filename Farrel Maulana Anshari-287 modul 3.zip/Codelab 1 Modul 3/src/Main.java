// Kelas utama untuk simulasi pertarungan
public class Main {
    public static void main(String[] args) {
        // Membuat objek karakter umum sebagai instance dari class KarakterGame
        KarakterGame karakterUmum = new KarakterGame("Karakter Umum", 100);

        // Membuat objek Pahlawan bernama Brimstone dengan kesehatan awal 150
        Pahlawan brimstone = new Pahlawan("Brimstone", 150);

        // Membuat objek Musuh bernama Viper dengan kesehatan awal 200
        Musuh viper = new Musuh("Viper", 200);

        // Menampilkan status awal semua karakter
        System.out.println("Status awal:");
        System.out.println(brimstone.getNama() + " memiliki kesehatan: " + brimstone.getKesehatan());
        System.out.println(viper.getNama() + " memiliki kesehatan: " + viper.getKesehatan());

        // Pahlawan menyerang Musuh
        brimstone.serang(viper);

        // Musuh menyerang Pahlawan
        viper.serang(brimstone);
    }
}