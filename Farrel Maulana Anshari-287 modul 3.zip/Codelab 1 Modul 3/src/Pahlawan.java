// Subclass Pahlawan, yang merupakan turunan dari class KarakterGame
class Pahlawan extends KarakterGame {
    // Constructor untuk class Pahlawan
    // Digunakan untuk mengatur nama dan kesehatan awal dari objek Pahlawan
    public Pahlawan(String nama, int kesehatan) {
        super(nama, kesehatan); // Memanggil constructor superclass (KarakterGame)
    }
    // Method ini mendefinisikan bagaimana Pahlawan menyerang target
    @Override
    public void serang(KarakterGame target) {
        // Menampilkan pesan bahwa Pahlawan menyerang target dengan serangan khusus
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan Orbital Strike!");

        // Mengurangi kesehatan target sebesar 20
        target.setKesehatan(target.getKesehatan() - 20);

        // Menampilkan kesehatan terbaru target setelah diserang
        System.out.println(target.getNama() + " sekarang memiliki kesehatan " + target.getKesehatan());
    }
}